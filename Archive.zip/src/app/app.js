'use strict';

var React = require('react');

React.render(
    document.getElementById('app')
);